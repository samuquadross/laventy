import { Check, X, ArrowRight } from 'lucide-react';
import { Link } from 'wouter';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const subscriptionPlans = [
  {
    id: 1,
    name: 'Básico',
    price: '18€',
    period: '/mês',
    description: '1 vela premium por mês',
    originalPrice: '22€',
    savings: '18%',
    image: '/images/hero-candles.jpg',
    features: [
      { text: '1 vela aromática premium', included: true },
      { text: 'Fragrâncias rotativas', included: true },
      { text: 'Entrega mensal gratuita', included: true },
      { text: 'Pausa/cancelamento flexível', included: true },
      { text: 'Acesso a vendas exclusivas', included: false },
      { text: 'Personalização de fragrâncias', included: false },
    ],
    frequency: ['Mensal', 'Trimestral', 'Anual'],
    cta: 'Assinar Básico',
  },
  {
    id: 2,
    name: 'Essencial',
    price: '35€',
    period: '/mês',
    description: '2 velas + 1 difusor',
    originalPrice: '45€',
    savings: '22%',
    image: '/images/subscription-box.jpg',
    featured: true,
    features: [
      { text: '2 velas aromáticas premium', included: true },
      { text: '1 difusor de ambiente', included: true },
      { text: 'Fragrâncias rotativas', included: true },
      { text: 'Entrega mensal gratuita', included: true },
      { text: 'Pausa/cancelamento flexível', included: true },
      { text: 'Acesso a vendas exclusivas', included: true },
      { text: 'Personalização de fragrâncias', included: false },
    ],
    frequency: ['Mensal', 'Trimestral', 'Anual'],
    cta: 'Assinar Essencial',
  },
  {
    id: 3,
    name: 'Pet-Safe',
    price: '28€',
    period: '/mês',
    description: 'Seleção segura para animais',
    originalPrice: '35€',
    savings: '20%',
    image: '/images/pet-safe-collection.jpg',
    features: [
      { text: 'Velas pet-safe certificadas', included: true },
      { text: 'Óleos essenciais seguros', included: true },
      { text: 'Sem produtos tóxicos', included: true },
      { text: 'Entrega mensal gratuita', included: true },
      { text: 'Pausa/cancelamento flexível', included: true },
      { text: 'Acesso a vendas exclusivas', included: true },
      { text: 'Consulta com especialista pet', included: true },
    ],
    frequency: ['Mensal', 'Trimestral', 'Anual'],
    cta: 'Assinar Pet-Safe',
  },
];

const faqs = [
  {
    question: 'Como funciona a assinatura?',
    answer: 'Você escolhe seu plano, frequência de entrega (mensal, trimestral ou anual) e recebe sua caixa curada automaticamente. Pode pausar ou cancelar a qualquer momento sem multa.',
  },
  {
    question: 'Posso mudar de fragrância?',
    answer: 'Sim! Você pode personalizar suas fragrâncias antes de cada entrega. Basta acessar sua conta e selecionar as fragrâncias desejadas.',
  },
  {
    question: 'Qual é a política de cancelamento?',
    answer: 'Você pode pausar sua assinatura por até 3 meses ou cancelar a qualquer momento. Não há multas ou taxas de cancelamento.',
  },
  {
    question: 'Há envio grátis?',
    answer: 'Sim! Todas as assinaturas incluem envio grátis em Portugal Continental. Entregas em Açores e Madeira têm taxa adicional.',
  },
  {
    question: 'Posso fazer upgrade ou downgrade?',
    answer: 'Claro! Você pode mudar de plano a qualquer momento. A mudança será refletida na próxima cobrança.',
  },
  {
    question: 'Como funciona o desconto Subscribe & Save?',
    answer: 'Assinantes recebem automaticamente 15-22% de desconto comparado ao preço de compra única. Quanto maior o plano, maior o desconto.',
  },
];

export default function Subscriptions() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero */}
      <section className="py-12 md:py-20 bg-primary/5 border-b border-primary/10">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Clube Laventy
          </h1>
          <p className="text-foreground/70 text-lg max-w-2xl">
            Assinaturas sensoriais curadas para trazer calma e propósito ao seu lar. Economize até 22% com entrega automática.
          </p>
        </div>
      </section>

      {/* Plans */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {subscriptionPlans.map((plan) => (
              <div
                key={plan.id}
                className={`relative rounded-lg overflow-hidden shadow-sensorial transition-sensorial ${
                  plan.featured
                    ? 'md:scale-105 border-2 border-primary bg-primary/5'
                    : 'border border-primary/10 bg-background'
                }`}
              >
                {plan.featured && (
                  <div className="absolute top-0 left-0 right-0 bg-primary text-primary-foreground py-2 text-center text-sm font-semibold">
                    Mais Popular
                  </div>
                )}

                <div className="relative h-64 overflow-hidden bg-muted">
                  <img
                    src={plan.image}
                    alt={plan.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className={`p-8 ${plan.featured ? 'pt-12' : ''}`}>
                  <h3 className="text-2xl font-bold text-foreground mb-2">
                    {plan.name}
                  </h3>
                  <p className="text-foreground/60 text-sm mb-6">{plan.description}</p>

                  <div className="mb-6">
                    <div className="flex items-baseline gap-2 mb-2">
                      <span className="text-4xl font-bold text-primary">
                        {plan.price}
                      </span>
                      <span className="text-foreground/60 text-sm">{plan.period}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-foreground/60 line-through">
                        {plan.originalPrice}
                      </span>
                      <span className="text-sm font-semibold text-accent">
                        Economize {plan.savings}
                      </span>
                    </div>
                  </div>

                  <div className="mb-6">
                    <p className="text-xs font-semibold text-foreground/60 uppercase mb-3">
                      Frequência
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {plan.frequency.map((freq) => (
                        <button
                          key={freq}
                          className="px-3 py-1 border border-primary/30 rounded text-xs font-medium hover:bg-primary/10 transition-sensorial"
                        >
                          {freq}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    className={`w-full py-3 rounded-lg font-semibold transition-sensorial mb-6 flex items-center justify-center gap-2 ${
                      plan.featured
                        ? 'bg-primary text-primary-foreground hover:opacity-90'
                        : 'border border-primary/30 text-foreground hover:bg-primary/5'
                    }`}
                  >
                    {plan.cta}
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <div className="space-y-3 border-t border-primary/10 pt-6">
                    {plan.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        {feature.included ? (
                          <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                        ) : (
                          <X className="w-5 h-5 text-foreground/20 flex-shrink-0 mt-0.5" />
                        )}
                        <span
                          className={`text-sm ${
                            feature.included
                              ? 'text-foreground'
                              : 'text-foreground/40'
                          }`}
                        >
                          {feature.text}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12 text-center">
            Como Funciona
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              {
                step: '1',
                title: 'Escolha seu Plano',
                description: 'Selecione o plano que melhor se adequa ao seu estilo de vida.',
              },
              {
                step: '2',
                title: 'Escolha a Frequência',
                description: 'Mensal, trimestral ou anual. Você controla o ritmo.',
              },
              {
                step: '3',
                title: 'Receba Automaticamente',
                description: 'Sua caixa curada chega na sua porta conforme agendado.',
              },
              {
                step: '4',
                title: 'Gerencie Quando Quiser',
                description: 'Pause, cancele ou mude de plano a qualquer momento.',
              },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-4">
                  {item.step}
                </div>
                <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-foreground/60 text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-24">
        <div className="container max-w-3xl">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-12 text-center">
            Perguntas Frequentes
          </h2>

          <div className="space-y-6">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="p-6 bg-muted/30 rounded-lg border border-primary/10 hover:border-primary/30 transition-sensorial"
              >
                <h3 className="font-semibold text-foreground mb-3">{faq.question}</h3>
                <p className="text-foreground/70 text-sm leading-relaxed">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-24 bg-primary/5 border-t border-primary/10">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
            Comece Sua Jornada Sensorial
          </h2>
          <p className="text-foreground/60 mb-8 max-w-2xl mx-auto">
            Primeira compra com 15% de desconto. Sem compromisso - cancele quando quiser.
          </p>
          <button className="inline-flex items-center justify-center px-8 py-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition-sensorial text-lg">
            Assinar Agora
            <ArrowRight className="w-5 h-5 ml-2" />
          </button>
        </div>
      </section>

      <Footer />
    </div>
  );
}
