import { ArrowRight, Sparkles, Gift, Leaf, Heart } from 'lucide-react';
import { Link } from 'wouter';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';

export default function Home() {
  const subscriptionPlans = [
    {
      id: 1,
      name: 'Básico',
      price: '18€',
      description: '1 vela premium por mês',
      savings: 'Economize 18% vs. compra avulsa',
      image: '/images/hero-candles.jpg',
    },
    {
      id: 2,
      name: 'Essencial',
      price: '35€',
      description: '2 velas + 1 difusor',
      savings: 'Economize 22% vs. compra avulsa',
      image: '/images/subscription-box.jpg',
    },
    {
      id: 3,
      name: 'Pet-Safe',
      price: '28€',
      description: 'Seleção segura para animais',
      savings: 'Economize 20% vs. compra avulsa',
      image: '/images/pet-safe-collection.jpg',
    },
  ];

  const benefits = [
    {
      icon: Gift,
      title: 'Entrega Automática',
      description: 'Receba sua caixa curada todo mês na sua porta',
    },
    {
      icon: Sparkles,
      title: 'Desconto Exclusivo',
      description: 'Economize até 22% em assinaturas vs. compra única',
    },
    {
      icon: Leaf,
      title: 'Seleção Curada',
      description: 'Fragrâncias rotativas escolhidas por artesãos',
    },
    {
      icon: Heart,
      title: 'Pausa Quando Quiser',
      description: 'Flexibilidade total - pause ou cancele sem multa',
    },
  ];

  const products = [
    {
      id: 1,
      name: 'Vela Lavanda Relax',
      price: '22€',
      image: '/images/hero-candles.jpg',
      badge: 'Assinatura disponível',
    },
    {
      id: 2,
      name: 'Difusor Jasmim Noturno',
      price: '28€',
      image: '/images/pet-safe-collection.jpg',
      badge: 'Pet-Safe',
    },
    {
      id: 3,
      name: 'Kit Verbena Fresca',
      price: '35€',
      image: '/images/lifestyle-ambiance.jpg',
      badge: 'Assinatura disponível',
    },
    {
      id: 4,
      name: 'Vela Eucalipto Menta',
      price: '22€',
      image: '/images/hero-candles.jpg',
      badge: 'Novo',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-0 min-h-[600px] md:min-h-[700px]">
          {/* Left: Text */}
          <div className="flex flex-col justify-center px-6 md:px-12 py-12 md:py-0">
            <div className="max-w-md">
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 leading-tight">
                Assine e Receba Calma em Casa
              </h1>
              <p className="text-foreground/70 text-lg mb-8 leading-relaxed">
                Velas aromáticas handmade, difusores e coleções pet-safe. Design sensorial de Lisboa entregue todo mês.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/subscriptions">
                  <a className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:opacity-90 transition-sensorial">
                    Começar Assinatura
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </a>
                </Link>
                <Link href="/products">
                  <a className="inline-flex items-center justify-center px-6 py-3 border border-primary/30 text-foreground rounded-lg font-medium hover:bg-primary/5 transition-sensorial">
                    Ver Produtos
                  </a>
                </Link>
              </div>
            </div>
          </div>

          {/* Right: Image */}
          <div className="hidden md:block relative overflow-hidden">
            <img
              src="/images/hero-candles.jpg"
              alt="Velas aromáticas Laventy"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-l from-transparent to-background/20"></div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 text-foreground">
            Por Que Assinar?
          </h2>
          <p className="text-center text-foreground/60 mb-12 max-w-2xl mx-auto">
            Benefícios exclusivos para membros do Clube Laventy
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit) => {
              const Icon = benefit.icon;
              return (
                <div key={benefit.title} className="p-6 bg-background rounded-lg shadow-sensorial border border-primary/10 hover:shadow-lg transition-sensorial">
                  <Icon className="w-8 h-8 text-primary mb-4" />
                  <h3 className="font-semibold text-foreground mb-2">{benefit.title}</h3>
                  <p className="text-foreground/60 text-sm">{benefit.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Subscriptions */}
      <section className="py-16 md:py-24">
        <div className="container">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
            Assinaturas Populares
          </h2>
          <p className="text-foreground/60 mb-12 max-w-2xl">
            Escolha seu plano ideal ou customize sua caixa mensal
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {subscriptionPlans.map((plan) => (
              <div
                key={plan.id}
                className="group bg-background rounded-lg overflow-hidden shadow-sensorial hover:shadow-lg transition-sensorial border border-primary/10"
              >
                <div className="relative h-64 overflow-hidden bg-muted">
                  <img
                    src={plan.image}
                    alt={plan.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-2">{plan.name}</h3>
                  <p className="text-foreground/60 text-sm mb-4">{plan.description}</p>
                  <div className="mb-4">
                    <p className="text-3xl font-bold text-primary mb-2">{plan.price}</p>
                    <p className="text-xs text-accent font-medium">{plan.savings}</p>
                  </div>
                  <Link href="/subscriptions">
                    <a className="w-full inline-flex items-center justify-center px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:opacity-90 transition-sensorial">
                      Assinar Agora
                    </a>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
                Produtos em Destaque
              </h2>
              <p className="text-foreground/60">
                Compre avulso ou combine com sua assinatura
              </p>
            </div>
            <Link href="/products">
              <a className="hidden md:inline-flex items-center text-primary hover:text-primary/80 transition-sensorial font-medium">
                Ver Todos
                <ArrowRight className="w-4 h-4 ml-2" />
              </a>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <div
                key={product.id}
                className="group bg-background rounded-lg overflow-hidden shadow-sensorial hover:shadow-lg transition-sensorial border border-primary/10"
              >
                <div className="relative h-56 overflow-hidden bg-muted">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 right-3">
                    <span className="inline-block px-3 py-1 bg-primary text-primary-foreground text-xs font-medium rounded-full">
                      {product.badge}
                    </span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-foreground mb-2 line-clamp-2">
                    {product.name}
                  </h3>
                  <p className="text-lg font-bold text-primary mb-4">{product.price}</p>
                  <button className="w-full px-4 py-2 border border-primary/30 text-foreground rounded-lg font-medium hover:bg-primary/5 transition-sensorial text-sm">
                    Ver Detalhes
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-8 md:hidden">
            <Link href="/products">
              <a className="inline-flex items-center text-primary hover:text-primary/80 transition-sensorial font-medium">
                Ver Todos os Produtos
                <ArrowRight className="w-4 h-4 ml-2" />
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary/5 border-t border-primary/10">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
            Pronto para Começar?
          </h2>
          <p className="text-foreground/60 mb-8 max-w-2xl mx-auto">
            Junte-se ao Clube Laventy e receba design sensorial todos os meses. Primeira compra com 15% de desconto.
          </p>
          <Link href="/subscriptions">
            <a className="inline-flex items-center justify-center px-8 py-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition-sensorial text-lg">
              Assinar Agora
              <ArrowRight className="w-5 h-5 ml-2" />
            </a>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
