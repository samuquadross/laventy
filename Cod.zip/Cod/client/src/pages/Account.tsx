import { LogOut, Settings, Calendar, Pause, Trash2, Edit2 } from 'lucide-react';
import { Link } from 'wouter';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const activeSubscriptions = [
  {
    id: 1,
    name: 'Plano Essencial',
    status: 'Ativa',
    price: '35€/mês',
    nextDelivery: '15 de Fevereiro',
    frequency: 'Mensal',
    items: ['2 velas premium', '1 difusor'],
    startDate: '15 de Janeiro',
  },
  {
    id: 2,
    name: 'Plano Pet-Safe',
    status: 'Ativa',
    price: '28€/mês',
    nextDelivery: '20 de Fevereiro',
    frequency: 'Mensal',
    items: ['Velas pet-safe', 'Óleos essenciais'],
    startDate: '20 de Janeiro',
  },
];

const orderHistory = [
  {
    id: 'LAV-001',
    date: '15 de Janeiro 2024',
    total: '35€',
    status: 'Entregue',
    items: 'Plano Essencial - Janeiro',
  },
  {
    id: 'LAV-002',
    date: '10 de Janeiro 2024',
    total: '22€',
    status: 'Entregue',
    items: 'Vela Lavanda Relax',
  },
  {
    id: 'LAV-003',
    date: '5 de Janeiro 2024',
    total: '28€',
    status: 'Entregue',
    items: 'Plano Pet-Safe - Janeiro',
  },
];

export default function Account() {
  const user = {
    name: 'Maria Silva',
    email: 'maria@example.com',
    phone: '+351 91 234 5678',
    address: 'Rua das Flores, 123, Lisboa',
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero */}
      <section className="py-12 md:py-16 bg-primary/5 border-b border-primary/10">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2">
            Minha Conta
          </h1>
          <p className="text-foreground/70">
            Gerencie suas assinaturas, pedidos e informações pessoais
          </p>
        </div>
      </section>

      {/* Content */}
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <aside className="lg:col-span-1">
            <div className="bg-muted/30 rounded-lg p-6 border border-primary/10 mb-6">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-lg">
                    {user.name.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-foreground">{user.name}</p>
                  <p className="text-sm text-foreground/60">{user.email}</p>
                </div>
              </div>
              <button className="w-full flex items-center justify-center gap-2 px-4 py-2 border border-primary/30 text-foreground rounded-lg hover:bg-primary/5 transition-sensorial text-sm font-medium">
                <LogOut className="w-4 h-4" />
                Sair
              </button>
            </div>

            <nav className="space-y-2">
              <button className="w-full text-left px-4 py-3 bg-primary/10 text-primary rounded-lg font-medium transition-sensorial">
                Assinaturas
              </button>
              <button className="w-full text-left px-4 py-3 text-foreground/60 hover:text-foreground rounded-lg transition-sensorial">
                Pedidos
              </button>
              <button className="w-full text-left px-4 py-3 text-foreground/60 hover:text-foreground rounded-lg transition-sensorial">
                Perfil
              </button>
              <button className="w-full text-left px-4 py-3 text-foreground/60 hover:text-foreground rounded-lg transition-sensorial">
                Endereços
              </button>
            </nav>
          </aside>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Active Subscriptions */}
            <section>
              <h2 className="text-2xl font-bold text-foreground mb-6">Minhas Assinaturas</h2>
              <div className="space-y-6">
                {activeSubscriptions.map((sub) => (
                  <div
                    key={sub.id}
                    className="p-6 bg-background rounded-lg shadow-sensorial border border-primary/10 hover:shadow-lg transition-sensorial"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-bold text-foreground mb-1">
                          {sub.name}
                        </h3>
                        <p className="text-sm text-foreground/60">
                          Ativa desde {sub.startDate}
                        </p>
                      </div>
                      <span className="px-3 py-1 bg-accent/20 text-accent font-semibold text-xs rounded-full">
                        {sub.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-muted/30 rounded-lg">
                      <div>
                        <p className="text-xs text-foreground/60 uppercase mb-1">Preço</p>
                        <p className="font-bold text-foreground">{sub.price}</p>
                      </div>
                      <div>
                        <p className="text-xs text-foreground/60 uppercase mb-1">Frequência</p>
                        <p className="font-bold text-foreground">{sub.frequency}</p>
                      </div>
                      <div>
                        <p className="text-xs text-foreground/60 uppercase mb-1">Próxima Entrega</p>
                        <p className="font-bold text-foreground">{sub.nextDelivery}</p>
                      </div>
                      <div>
                        <p className="text-xs text-foreground/60 uppercase mb-1">Itens</p>
                        <p className="font-bold text-foreground">{sub.items.length} itens</p>
                      </div>
                    </div>

                    <div className="mb-4">
                      <p className="text-sm font-semibold text-foreground mb-2">Conteúdo:</p>
                      <ul className="space-y-1">
                        {sub.items.map((item, idx) => (
                          <li key={idx} className="text-sm text-foreground/70 flex items-center gap-2">
                            <span className="w-1.5 h-1.5 bg-primary rounded-full"></span>
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex flex-wrap gap-3">
                      <button className="flex items-center gap-2 px-4 py-2 border border-primary/30 text-foreground rounded-lg hover:bg-primary/5 transition-sensorial text-sm font-medium">
                        <Edit2 className="w-4 h-4" />
                        Personalizar
                      </button>
                      <button className="flex items-center gap-2 px-4 py-2 border border-primary/30 text-foreground rounded-lg hover:bg-primary/5 transition-sensorial text-sm font-medium">
                        <Pause className="w-4 h-4" />
                        Pausar
                      </button>
                      <button className="flex items-center gap-2 px-4 py-2 border border-destructive/30 text-destructive rounded-lg hover:bg-destructive/5 transition-sensorial text-sm font-medium">
                        <Trash2 className="w-4 h-4" />
                        Cancelar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Order History */}
            <section>
              <h2 className="text-2xl font-bold text-foreground mb-6">Histórico de Pedidos</h2>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-primary/10">
                      <th className="text-left py-3 px-4 text-sm font-semibold text-foreground/60">Pedido</th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-foreground/60">Data</th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-foreground/60">Itens</th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-foreground/60">Total</th>
                      <th className="text-left py-3 px-4 text-sm font-semibold text-foreground/60">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orderHistory.map((order) => (
                      <tr key={order.id} className="border-b border-primary/10 hover:bg-muted/30 transition-sensorial">
                        <td className="py-4 px-4 text-sm font-medium text-primary">{order.id}</td>
                        <td className="py-4 px-4 text-sm text-foreground/70">{order.date}</td>
                        <td className="py-4 px-4 text-sm text-foreground/70">{order.items}</td>
                        <td className="py-4 px-4 text-sm font-bold text-foreground">{order.total}</td>
                        <td className="py-4 px-4 text-sm">
                          <span className="px-3 py-1 bg-accent/20 text-accent font-semibold text-xs rounded-full">
                            {order.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
