import { ArrowRight } from 'lucide-react';
import { Link } from 'wouter';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <div className="flex-1 flex items-center justify-center">
        <div className="container text-center py-20">
          <h1 className="text-6xl md:text-8xl font-bold text-primary mb-4">404</h1>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Página não encontrada
          </h2>
          <p className="text-foreground/60 text-lg mb-8 max-w-md mx-auto">
            Desculpe, a página que você está procurando não existe ou foi movida.
          </p>
          <Link href="/">
            <a className="inline-flex items-center justify-center px-8 py-4 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition-sensorial">
              Voltar para Home
              <ArrowRight className="w-5 h-5 ml-2" />
            </a>
          </Link>
        </div>
      </div>

      <Footer />
    </div>
  );
}
