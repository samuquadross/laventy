import { Filter } from 'lucide-react';
import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const allProducts = [
  {
    id: 1,
    name: 'Vela Lavanda Relax',
    price: '22€',
    category: 'Velas',
    fragrance: 'Lavanda',
    type: 'Assinatura',
    image: '/images/hero-candles.jpg',
  },
  {
    id: 2,
    name: 'Difusor Jasmim Noturno',
    price: '28€',
    category: 'Difusores',
    fragrance: 'Jasmim',
    type: 'Pet-Safe',
    image: '/images/pet-safe-collection.jpg',
  },
  {
    id: 3,
    name: 'Kit Verbena Fresca',
    price: '35€',
    category: 'Kits',
    fragrance: 'Verbena',
    type: 'Assinatura',
    image: '/images/lifestyle-ambiance.jpg',
  },
  {
    id: 4,
    name: 'Vela Eucalipto Menta',
    price: '22€',
    category: 'Velas',
    fragrance: 'Eucalipto',
    type: 'Novo',
    image: '/images/hero-candles.jpg',
  },
  {
    id: 5,
    name: 'Difusor Pet-Safe Camomila',
    price: '26€',
    category: 'Difusores',
    fragrance: 'Camomila',
    type: 'Pet-Safe',
    image: '/images/pet-safe-collection.jpg',
  },
  {
    id: 6,
    name: 'Vela Rosa Clássica',
    price: '24€',
    category: 'Velas',
    fragrance: 'Rosa',
    type: 'Assinatura',
    image: '/images/subscription-box.jpg',
  },
  {
    id: 7,
    name: 'Kit Completo Sensorial',
    price: '45€',
    category: 'Kits',
    fragrance: 'Misto',
    type: 'Assinatura',
    image: '/images/lifestyle-ambiance.jpg',
  },
  {
    id: 8,
    name: 'Vela Cedro Profundo',
    price: '25€',
    category: 'Velas',
    fragrance: 'Cedro',
    type: 'Novo',
    image: '/images/hero-candles.jpg',
  },
];

export default function Products() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedFragrance, setSelectedFragrance] = useState<string | null>(null);
  const [priceRange, setPriceRange] = useState([0, 50]);
  const [sortBy, setSortBy] = useState('popular');

  const categories = ['Velas', 'Difusores', 'Kits', 'Acessórios'];
  const fragrances = ['Lavanda', 'Jasmim', 'Verbena', 'Eucalipto', 'Rosa', 'Cedro', 'Camomila'];

  const filteredProducts = allProducts.filter((product) => {
    const categoryMatch = !selectedCategory || product.category === selectedCategory;
    const fragranceMatch = !selectedFragrance || product.fragrance === selectedFragrance;
    const priceMatch = parseInt(product.price) <= priceRange[1];
    return categoryMatch && fragranceMatch && priceMatch;
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero */}
      <section className="py-12 md:py-16 bg-primary/5 border-b border-primary/10">
        <div className="container">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2">
            Catálogo de Produtos
          </h1>
          <p className="text-foreground/70">
            Velas aromáticas, difusores e coleções pet-safe handmade
          </p>
        </div>
      </section>

      {/* Content */}
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar - Filters */}
          <aside className="lg:col-span-1">
            <div className="sticky top-20 space-y-6">
              {/* Category Filter */}
              <div>
                <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  Categoria
                </h3>
                <div className="space-y-2">
                  <button
                    onClick={() => setSelectedCategory(null)}
                    className={`w-full text-left px-3 py-2 rounded transition-sensorial ${
                      selectedCategory === null
                        ? 'bg-primary/10 text-primary font-medium'
                        : 'text-foreground/60 hover:text-foreground'
                    }`}
                  >
                    Todos
                  </button>
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`w-full text-left px-3 py-2 rounded transition-sensorial ${
                        selectedCategory === cat
                          ? 'bg-primary/10 text-primary font-medium'
                          : 'text-foreground/60 hover:text-foreground'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Fragrance Filter */}
              <div className="border-t border-primary/10 pt-6">
                <h3 className="font-semibold text-foreground mb-4">Fragrância</h3>
                <div className="space-y-2">
                  <button
                    onClick={() => setSelectedFragrance(null)}
                    className={`w-full text-left px-3 py-2 rounded transition-sensorial ${
                      selectedFragrance === null
                        ? 'bg-primary/10 text-primary font-medium'
                        : 'text-foreground/60 hover:text-foreground'
                    }`}
                  >
                    Todas
                  </button>
                  {fragrances.map((frag) => (
                    <button
                      key={frag}
                      onClick={() => setSelectedFragrance(frag)}
                      className={`w-full text-left px-3 py-2 rounded transition-sensorial ${
                        selectedFragrance === frag
                          ? 'bg-primary/10 text-primary font-medium'
                          : 'text-foreground/60 hover:text-foreground'
                      }`}
                    >
                      {frag}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Filter */}
              <div className="border-t border-primary/10 pt-6">
                <h3 className="font-semibold text-foreground mb-4">Preço</h3>
                <div className="space-y-4">
                  <input
                    type="range"
                    min="0"
                    max="50"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([0, parseInt(e.target.value)])}
                    className="w-full"
                  />
                  <div className="text-sm text-foreground/60">
                    Até {priceRange[1]}€
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Sort */}
            <div className="flex items-center justify-between mb-8">
              <p className="text-foreground/60 text-sm">
                {filteredProducts.length} produtos encontrados
              </p>
              <div className="flex items-center gap-2">
                <label className="text-sm text-foreground/60">Ordenar por:</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-3 py-2 border border-primary/20 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 bg-background"
                >
                  <option value="popular">Mais Popular</option>
                  <option value="newest">Mais Novo</option>
                  <option value="price-low">Menor Preço</option>
                  <option value="price-high">Maior Preço</option>
                </select>
              </div>
            </div>

            {/* Products Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className="group bg-background rounded-lg overflow-hidden shadow-sensorial hover:shadow-lg transition-sensorial border border-primary/10"
                >
                  <div className="relative h-56 overflow-hidden bg-muted">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute top-3 right-3">
                      <span className="inline-block px-3 py-1 bg-primary text-primary-foreground text-xs font-medium rounded-full">
                        {product.type}
                      </span>
                    </div>
                  </div>
                  <div className="p-4">
                    <p className="text-xs text-foreground/50 uppercase mb-1">{product.category}</p>
                    <h3 className="font-semibold text-foreground mb-2 line-clamp-2">
                      {product.name}
                    </h3>
                    <p className="text-xs text-foreground/60 mb-4">{product.fragrance}</p>
                    <div className="flex items-center justify-between">
                      <p className="text-lg font-bold text-primary">{product.price}</p>
                      <button className="px-3 py-2 border border-primary/30 text-foreground rounded-lg font-medium hover:bg-primary/5 transition-sensorial text-sm">
                        Ver
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <p className="text-foreground/60 mb-4">Nenhum produto encontrado com esses filtros.</p>
                <button
                  onClick={() => {
                    setSelectedCategory(null);
                    setSelectedFragrance(null);
                  }}
                  className="text-primary hover:text-primary/80 transition-sensorial font-medium"
                >
                  Limpar filtros
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
