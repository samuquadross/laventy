import { Mail, MapPin, Phone, Instagram, Facebook } from 'lucide-react';
import { Link } from 'wouter';

export default function Footer() {
  return (
    <footer className="bg-muted/30 border-t border-primary/10 mt-20">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">L</span>
              </div>
              <span className="font-bold text-foreground">Laventy Studio</span>
            </div>
            <p className="text-foreground/60 text-sm leading-relaxed">
              Design sensorial handmade de Lisboa. Velas aromáticas, difusores e coleções pet-safe para trazer calma e propósito ao seu lar.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Navegação</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/products">
                  <a className="text-foreground/60 hover:text-foreground transition-sensorial">
                    Produtos
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/subscriptions">
                  <a className="text-foreground/60 hover:text-foreground transition-sensorial">
                    Assinaturas
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <a className="text-foreground/60 hover:text-foreground transition-sensorial">
                    Sobre Nós
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <a className="text-foreground/60 hover:text-foreground transition-sensorial">
                    Contato
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Atendimento</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-foreground/60 hover:text-foreground transition-sensorial">
                  Perguntas Frequentes
                </a>
              </li>
              <li>
                <a href="#" className="text-foreground/60 hover:text-foreground transition-sensorial">
                  Política de Privacidade
                </a>
              </li>
              <li>
                <a href="#" className="text-foreground/60 hover:text-foreground transition-sensorial">
                  Termos de Serviço
                </a>
              </li>
              <li>
                <a href="#" className="text-foreground/60 hover:text-foreground transition-sensorial">
                  Rastreamento
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">Contacte-nos</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2 text-foreground/60">
                <MapPin className="w-4 h-4 text-primary" />
                <span>Lisboa, Portugal</span>
              </li>
              <li className="flex items-center gap-2 text-foreground/60">
                <Mail className="w-4 h-4 text-primary" />
                <a href="mailto:hello@laventy.studio" className="hover:text-foreground transition-sensorial">
                  hello@laventy.studio
                </a>
              </li>
              <li className="flex items-center gap-2 text-foreground/60">
                <Phone className="w-4 h-4 text-primary" />
                <span>+351 91 234 5678</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Newsletter */}
        <div className="bg-primary/5 rounded-lg p-6 mb-12 border border-primary/10">
          <h4 className="font-semibold text-foreground mb-2">Receba Novidades</h4>
          <p className="text-foreground/60 text-sm mb-4">
            Inscreva-se para receber ofertas exclusivas de assinatura e lançamentos de novas fragrâncias.
          </p>
          <div className="flex gap-2">
            <input
              type="email"
              placeholder="seu@email.com"
              className="flex-1 px-4 py-2 bg-background border border-primary/20 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
            <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 transition-sensorial">
              Inscrever
            </button>
          </div>
        </div>

        {/* Social & Bottom */}
        <div className="divider-lavender pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-foreground/50 text-sm">
            © 2024 Laventy Studio. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="p-2 hover:bg-muted rounded-lg transition-sensorial text-foreground/60 hover:text-foreground">
              <Instagram className="w-5 h-5" />
            </a>
            <a href="#" className="p-2 hover:bg-muted rounded-lg transition-sensorial text-foreground/60 hover:text-foreground">
              <Facebook className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
