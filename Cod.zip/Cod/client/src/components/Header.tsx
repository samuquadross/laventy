import { ShoppingBag, Search, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-background border-b border-primary/10">
      <div className="container">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link href="/">
            <a className="flex items-center gap-2 transition-sensorial hover:opacity-80">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">L</span>
              </div>
              <span className="hidden sm:inline font-bold text-lg text-foreground">
                Laventy Studio
              </span>
            </a>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/products">
              <a className="text-foreground/70 hover:text-foreground transition-sensorial text-sm font-medium">
                Produtos
              </a>
            </Link>
            <Link href="/subscriptions">
              <a className="text-foreground/70 hover:text-foreground transition-sensorial text-sm font-medium">
                Clube Laventy
              </a>
            </Link>
            <Link href="/about">
              <a className="text-foreground/70 hover:text-foreground transition-sensorial text-sm font-medium">
                Sobre
              </a>
            </Link>
            <Link href="/contact">
              <a className="text-foreground/70 hover:text-foreground transition-sensorial text-sm font-medium">
                Contato
              </a>
            </Link>
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-muted rounded-lg transition-sensorial hidden sm:inline-flex">
              <Search className="w-5 h-5 text-foreground/60" />
            </button>
            <Link href="/account">
              <a className="p-2 hover:bg-muted rounded-lg transition-sensorial hidden sm:inline-flex relative">
                <ShoppingBag className="w-5 h-5 text-foreground/60" />
                <span className="absolute top-0 right-0 w-2 h-2 bg-primary rounded-full"></span>
              </a>
            </Link>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 hover:bg-muted rounded-lg transition-sensorial"
            >
              {isMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden pb-4 border-t border-primary/10">
            <Link href="/products">
              <a className="block py-2 text-foreground/70 hover:text-foreground transition-sensorial">
                Produtos
              </a>
            </Link>
            <Link href="/subscriptions">
              <a className="block py-2 text-foreground/70 hover:text-foreground transition-sensorial">
                Clube Laventy
              </a>
            </Link>
            <Link href="/about">
              <a className="block py-2 text-foreground/70 hover:text-foreground transition-sensorial">
                Sobre
              </a>
            </Link>
            <Link href="/contact">
              <a className="block py-2 text-foreground/70 hover:text-foreground transition-sensorial">
                Contato
              </a>
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
}
